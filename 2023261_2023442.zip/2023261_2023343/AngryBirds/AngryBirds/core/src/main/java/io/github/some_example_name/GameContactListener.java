package io.github.some_example_name;

import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Manifold;

import java.util.List;

public class GameContactListener implements ContactListener {

    private List<CreateStructure> structures;
    private List<Pig> pigs;

    public GameContactListener(List<CreateStructure> structures, List<Pig> pigs) {
        this.structures = structures;
        this.pigs = pigs;
    }

    @Override
    public void beginContact(Contact contact) {
        if (structures != null) {
            for (CreateStructure structure : structures) {
                if (contact.getFixtureA().getBody() == structure.getBody() ||
                    contact.getFixtureB().getBody() == structure.getBody()) {
                    structure.handleCollision();
                }
            }
        }

        if (pigs != null) {
            for (Pig pig : pigs) {
                if (contact.getFixtureA().getBody() == pig.getBody() ||
                    contact.getFixtureB().getBody() == pig.getBody()) {
                    pig.handleCollision();
                }
            }
        }
    }

    @Override
    public void endContact(Contact contact) {
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }
}
