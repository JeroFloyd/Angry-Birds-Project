package io.github.some_example_name;

import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;

import java.util.ArrayList;
import java.util.List;

public class BodyDestructionManager {
    private final World world;
    private final List<Body> bodiesToDestroy;

    public BodyDestructionManager(World world) {
        this.world = world;
        this.bodiesToDestroy = new ArrayList<>();
    }

    public void addBodyToDestroy(Body body) {
        if (!bodiesToDestroy.contains(body)) {
            bodiesToDestroy.add(body);
        }
    }

    public void processDestruction() {
        for (Body body : bodiesToDestroy) {
            world.destroyBody(body);
        }
        bodiesToDestroy.clear();
    }
}


