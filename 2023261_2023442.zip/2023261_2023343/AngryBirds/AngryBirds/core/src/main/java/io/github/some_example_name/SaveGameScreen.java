package io.github.some_example_name;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.ArrayList;
import java.util.List;

public class SaveGameScreen implements Screen {

    private ShapeRenderer shapeRenderer;
    private Box2DDebugRenderer debugRenderer;
    private World world;
    private Catapult catapult;
    private List<CreateStructure> structures;
    private List<Pig> pigs;
    private Stage stage;
    private Skin skin;
    private GameState loadedState;
    private Game game;

    private OrthographicCamera camera;
    public SaveGameScreen(GameState loadedState,Game game) {
        this.loadedState = loadedState;
        this.game=game;
        shapeRenderer = new ShapeRenderer();
        debugRenderer = new Box2DDebugRenderer();
        world = new World(new Vector2(0, -9.8f), true);
        this.structures = new ArrayList<>();
        this.pigs = new ArrayList<>();
    }

    @Override
    public void show() {
        camera = new OrthographicCamera();
        stage = new Stage(new ScreenViewport(camera));
        Gdx.input.setInputProcessor(stage);
        skin = new Skin(Gdx.files.internal("skin-composer-ui.json"));
        catapult = new Catapult(world, camera, 300, 250, skin, stage, pigs);

        for (int i = 0; i < loadedState.getStructurePositions().size(); i++) {
            Vector2 position = loadedState.getStructurePositions().get(i);
            int remainingCollisions = loadedState.getRemainingCollisionsStructures().get(i);
            List<Integer> size = loadedState.getStructureSizes().get(i);
            structures.add(new CreateStructure(world, position.x, position.y, size.get(0), size.get(1), remainingCollisions+5));
        }

        for (int i = 0; i < loadedState.getPigPositions().size(); i++) {
            Vector2 position = loadedState.getPigPositions().get(i);
            Float size = loadedState.getPigSizes().get(i);
            int remainingCollisions = loadedState.getRemainingCollisionsPigs().get(i);
            pigs.add(new Pig(world, position.x, position.y, size, remainingCollisions+5, stage, skin, game));
        }
        createGround();
    }
    private void createGround() {
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.position.set(0, -0.5f);

        Body groundBody = world.createBody(groundBodyDef);

        PolygonShape groundBox = new PolygonShape();
        groundBox.setAsBox(1200, 20f);

        groundBody.createFixture(groundBox, 0.0f);

        groundBox.dispose();
    }
    @Override
    public void render(float delta) {

        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        world.step(1 / 60f, 6, 2);

        debugRenderer.render(world, camera.combined);

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (CreateStructure structure : structures) {
            structure.render(shapeRenderer);
        }

        for (Pig pig : pigs) {
            pig.render(shapeRenderer);
        }

        catapult.render();
        shapeRenderer.end();

        stage.act(delta);
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
        stage.dispose();
    }


}

