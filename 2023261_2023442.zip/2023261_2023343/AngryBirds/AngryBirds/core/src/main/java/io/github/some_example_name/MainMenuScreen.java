package io.github.some_example_name;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class MainMenuScreen implements Screen {
    private transient Game game;
    private transient OrthographicCamera camera;
    private transient Stage stage;
    private transient World world;
    private transient Catapult catapult;

    private int birdsleft;
    private transient Skin skin;
    private transient Texture backgroundTexture;
    private transient Image background;
    private transient BitmapFont font;

    public MainMenuScreen(Game game) {
        this.game = game;

    }

    @Override
    public void show() {
        camera = new OrthographicCamera();
        world = new World(new Vector2(0, -9.8f), true); // Gravity
        skin = new Skin(Gdx.files.internal("skin-composer-ui.json"));
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        skin = new Skin(Gdx.files.internal("skin-composer-ui.json"));

        backgroundTexture = new Texture(Gdx.files.internal("AngrybirdsBg.png"));
        background = new Image(backgroundTexture);
        background.setFillParent(true);
        stage.addActor(background);

        TextButton playButton1 = new TextButton("Play Level 1", skin);
        TextButton playButton2 = new TextButton("Play Level 2", skin);
        TextButton playButton3 = new TextButton("Play Level 3", skin);
        TextButton resumeButton = new TextButton("Join Previously Paused Game", skin);
        TextButton exitButton = new TextButton("Exit", skin);

        playButton1.setSize(500, 80);
        playButton2.setSize(500, 80);
        playButton3.setSize(500, 80);
        resumeButton.setSize(500, 80);
        exitButton.setSize(500, 80);

        playButton1.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new Level1Screen(game));
            }
        });

        playButton2.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new Level2Screen(game));
            }
        });

        playButton3.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new Level3Screen(game));
            }
        });
        resumeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                loadgame();
            }
        });
        Texture logoTexture = new Texture(Gdx.files.internal("logo.png"));
        Image logoImage = new Image(logoTexture);

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        table.add(logoImage).width(600).height(150).padBottom(20);
        table.row();
        table.add(playButton1).width(300).height(50).pad(10);
        table.row();
        table.add(playButton2).width(300).height(50).pad(10);
        table.row();
        table.add(playButton3).width(300).height(50).pad(10);
        table.row();
        table.add(resumeButton).width(300).height(50).pad(10);
        table.row();
        table.add(exitButton).width(300).height(50).pad(10);

        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(Gdx.gl.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }
    public void loadgame() {
        GameState loadedState = GameSaver.loadGame("game_state.ser");

        if (loadedState == null || loadedState.getLevel() == 0) {
            showEmptyScreen();
        } else {
            loadSavedGameState(loadedState);
        }
    }

    private void showEmptyScreen() {
        System.out.println("No saved game found or the game is empty. Redirecting to an empty screen...");
    }

    private void loadSavedGameState(GameState loadedState) {
        int level = loadedState.getLevel();

        switch (level) {
            case 1:
                System.out.println("Loading level 1...");
                break;
            case 2:
                System.out.println("Loading level 2...");
                break;
            default:
                System.out.println("Loading default or menu screen...");
                break;
        }

        recreateGameObjects(loadedState);
    }

    private void recreateGameObjects(GameState loadedState) {

        game.setScreen(new SaveGameScreen(loadedState,game));

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        disposeResources();
    }

    @Override
    public void dispose() {
        disposeResources();
    }

    private void disposeResources() {
        if (stage != null) {
            stage.dispose();
        }
        if (skin != null) {
            skin.dispose();
        }
        if (backgroundTexture != null) {
            backgroundTexture.dispose();
        }
    }
}

