package io.github.some_example_name;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;

import java.io.Serializable;

public class Pig implements Serializable {
    private transient World world;
    private transient Body body;
    private int collisionCount;
    private int maxCollisions;
    private float radius;
    private Stage stage;
    private Skin skin;
    private Game game;
    private boolean destroyed;

    private float bodyX, bodyY;
    private float bodyRadius;

    public Pig(World world, float x, float y, float radius, int maxCollisions, Stage stage, Skin skin, Game game) {
        this.world = world;
        this.radius = radius;
        this.maxCollisions = maxCollisions;
        this.collisionCount = 0;
        this.stage = stage;
        this.skin = skin;
        this.game = game;
        this.destroyed = false;

        this.bodyX = x;
        this.bodyY = y;
        this.bodyRadius = radius;

        createEnemy(x, y);
    }

    private void createEnemy(float x, float y) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(x, y);

        body = world.createBody(bodyDef);

        CircleShape shape = new CircleShape();
        shape.setRadius(radius);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 2f;
        fixtureDef.restitution = 0f;

        fixtureDef.filter.categoryBits = 0x0001;
        fixtureDef.filter.maskBits = 0x0001;

        body.createFixture(fixtureDef);
        shape.dispose();
    }

    public void dispose() {
        if (body != null) {
            body.getWorld().destroyBody(body);
        }
    }

    public void handleCollision() {
        collisionCount++;
        if (collisionCount >= maxCollisions) {
            destroyEnemy();
        }
    }

    private void destroyEnemy() {
        if (destroyed) return;

        destroyed = true;
        System.out.println("Pig destroyed after " + collisionCount + " collisions.");

        Gdx.app.postRunnable(() -> {
            if (body != null) {
                world.destroyBody(body);
                body = null;
            }
        });
    }

    public void render(ShapeRenderer shapeRenderer) {
        if (body != null) {
            shapeRenderer.setColor(Color.RED);
            shapeRenderer.circle(body.getPosition().x, body.getPosition().y, radius);
        }
    }

    public Body getBody() {
        return body;
    }

    public int getRemainingCollisions() {
        return maxCollisions - collisionCount;
    }

    public Vector2 getPosition() {
        return body != null ? body.getPosition() : new Vector2(bodyX, bodyY);
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public void restoreBody(World world) {
        if (body != null) {
            return;
        }

        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(bodyX, bodyY);

        body = world.createBody(bodyDef);

        CircleShape shape = new CircleShape();
        shape.setRadius(bodyRadius);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 2f;
        fixtureDef.restitution = 0f;

        body.createFixture(fixtureDef);
        shape.dispose();
    }

    public Float getsize() {
        return radius;
    }
}
