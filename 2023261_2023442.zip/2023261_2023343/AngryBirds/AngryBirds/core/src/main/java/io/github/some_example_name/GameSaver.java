package io.github.some_example_name;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import io.github.some_example_name.GameState;

import java.io.*;

public class GameSaver {
    public static void saveGame(GameState gameState, String filename) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(gameState);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static GameState loadGame(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (GameState) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}

