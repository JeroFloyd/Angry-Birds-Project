package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.Game;

import java.util.List;

public class CreateStructure {
    private World world;
    private Body body;
    private float width, height;
    private int collisionCount;
    private int maxCollisions;
    private boolean destroyed;

    public CreateStructure(World world, float x, float y, float width, float height, int maxCollisions) {
        this.world = world;
        this.width = width;
        this.height = height;
        this.maxCollisions = maxCollisions;
        this.collisionCount = 0;
        this.destroyed = false;

        createStructure(x, y, width, height);
    }

    private void createStructure(float x, float y, float width, float height) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(x, y);

        body = world.createBody(bodyDef);

        PolygonShape box = new PolygonShape();
        box.setAsBox(width / 2, height / 2);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = box;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 0.5f;
        fixtureDef.restitution = 0.1f;

        body.createFixture(fixtureDef);
        box.dispose();
    }

    public void handleCollision() {
        collisionCount++;
        if (collisionCount >= maxCollisions) {
            destroyStructure();
        }
    }

    private void destroyStructure() {
        if (destroyed) return;

        destroyed = true;
        System.out.println("Structure destroyed after " + collisionCount + " collisions.");
        Gdx.app.postRunnable(() -> {
            if (body != null) {
                world.destroyBody(body);
                body = null;
            }
        });
    }

    public void render(ShapeRenderer shapeRenderer) {
        if (body != null) {
            shapeRenderer.rect(body.getPosition().x - width / 2, body.getPosition().y - height / 2, width, height);
        }
    }

    public void dispose() {
        if (body != null) {
            body.getWorld().destroyBody(body);
        }
    }

    public Body getBody() {
        return body;
    }
    public int getRemainingCollisions() {
        return maxCollisions - collisionCount;
    }
    public Vector2 getPosition() {
        return body != null ? body.getPosition() : new Vector2(0, 0);
    }
    public List<Integer> getsize(){
        List<Integer> lst = new java.util.ArrayList<>() ;
        lst.add((int)width);
        lst.add((int)height);
        return lst;
    }
    public boolean isDestroyed() {
        return destroyed;
    }
}
