package io.github.some_example_name;

import java.io.Serializable;
import java.util.List;
import com.badlogic.gdx.math.Vector2;

public class GameState implements Serializable {
    private static final long serialVersionUID = 1L;

    private int level;
    private List<Integer> remainingCollisionsStructures;
    private List<Integer> remainingCollisionsPigs;
    private int remainingBirds;
    private List<Float> pigSizes;
    private List<List<Integer>> structureSizes;
    private List<Vector2> structurePositions;
    private List<Vector2> pigPositions;

    public GameState(int level, List<Integer> remainingCollisionsStructures, List<Integer> remainingCollisionsPigs,
                     int remainingBirds,
                     List<Float> pigSizes, List<List<Integer>> structureSizes, List<Vector2> structurePositions,
                     List<Vector2> pigPositions) {
        this.level = level;
        this.remainingCollisionsStructures = remainingCollisionsStructures;
        this.remainingCollisionsPigs = remainingCollisionsPigs;
        this.remainingBirds = remainingBirds;
        this.pigSizes = pigSizes;
        this.structureSizes = structureSizes;
        this.structurePositions = structurePositions;
        this.pigPositions = pigPositions;
    }

    public int getLevel() {
        return level;
    }

    public List<Integer> getRemainingCollisionsStructures() {
        return remainingCollisionsStructures;
    }

    public List<Integer> getRemainingCollisionsPigs() {
        return remainingCollisionsPigs;
    }

    public int getRemainingBirds() {
        return remainingBirds;
    }

    public List<Float> getPigSizes() {
        return pigSizes;
    }

    public List<List<Integer>> getStructureSizes() {
        return structureSizes;
    }

    public List<Vector2> getStructurePositions() {
        return structurePositions;
    }

    public List<Vector2> getPigPositions() {
        return pigPositions;
    }
}
