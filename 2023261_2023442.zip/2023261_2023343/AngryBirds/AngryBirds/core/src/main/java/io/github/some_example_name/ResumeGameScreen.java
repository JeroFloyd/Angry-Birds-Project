package io.github.some_example_name;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;

public class ResumeGameScreen implements Screen {
    private Game game;

    public ResumeGameScreen(Game game) {
        this.game = game;
    }

    @Override
    public void show() {
        System.out.println("Loading paused game...");
        game.setScreen(new GameScreen(game));
    }

    @Override
    public void render(float delta) {}

    @Override
    public void resize(int width, int height) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {}
}

