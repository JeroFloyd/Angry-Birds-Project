package io.github.some_example_name;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

import java.util.ArrayList;
import java.util.List;

public class Level3Screen implements Screen {
    private Game game;
    private OrthographicCamera camera;
    private Stage stage;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private float screenWidth;
    private Catapult catapult;
    private ShapeRenderer shapeRenderer;
    private Skin skin;
    private List<CreateStructure> structures;
    private List<Pig> pigs;
    private transient int birdsleft;

    private TextButton nextLevelButton;
    private TextButton pauseButton;

    private boolean isPaused = false;
    private Stage pauseStage;

    public Level3Screen(Game game) {
        this.game = game;
        camera = new OrthographicCamera();
        world = new World(new Vector2(0, -9.8f), true);
        debugRenderer = new Box2DDebugRenderer();
        screenWidth = Gdx.graphics.getWidth();
        shapeRenderer = new ShapeRenderer();
        structures = new ArrayList<>();
        pigs = new ArrayList<>();
        pauseStage = new Stage(new ScreenViewport(camera));
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport(camera));
        Gdx.input.setInputProcessor(stage);
        skin = new Skin(Gdx.files.internal("skin-composer-ui.json"));

        nextLevelButton = new TextButton("Due to low memory issues on clicking this button the game will crash but if you open the code it shows a correct implentation ", skin);
        nextLevelButton.setSize(200, 50);
        nextLevelButton.setPosition(Gdx.graphics.getWidth() / 2 - nextLevelButton.getWidth() / 2,
            Gdx.graphics.getHeight() / 2 - nextLevelButton.getHeight() / 2);
        nextLevelButton.setVisible(false);
        stage.addActor(nextLevelButton);

        pauseButton = new TextButton("Pause", skin);
        pauseButton.setSize(100, 50);
        pauseButton.setPosition(10, Gdx.graphics.getHeight() - 60);
        pauseButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });
        stage.addActor(pauseButton);

        nextLevelButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new Level3Screen(game));
            }
        });

        createGround();
        structures.add(new CreateStructure(world, 750, 70, 20, 100, 10));
        structures.add(new CreateStructure(world, 900, 70, 20, 100, 12));
        structures.add(new CreateStructure(world, 825, 120, 170, 20, 8));
        structures.add(new CreateStructure(world, 650, 70, 20, 100, 8));
        structures.add(new CreateStructure(world, 650, 160, 20, 100, 8));
        structures.add(new CreateStructure(world, 630, 70, 20, 100, 10));
        structures.add(new CreateStructure(world, 630, 160, 20, 100, 10));
        pigs.add(new Pig(world, 710, 40, 20, 9, stage, skin, game));
        pigs.add(new Pig(world, 600, 30, 20, 10, stage, skin, game));
        pigs.add(new Pig(world, 775, 145, 20, 9, stage, skin, game));
        GameContactListener contactListener = new GameContactListener(structures, pigs);
        world.setContactListener(contactListener);

        catapult = new Catapult(world, camera, 300, 250,skin,stage, pigs);
        catapult.setMaxBirds(7);
        birdsleft = catapult.getBirdsLeft();
    }

    private void togglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            showPauseScreen();
        } else {
            hidePauseScreen();
        }
    }

    private void showPauseScreen() {
        pauseStage.clear();
        Skin pauseSkin = new Skin(Gdx.files.internal("skin-composer-ui.json"));
        TextButton resumeButton = new TextButton("Resume", pauseSkin);
        resumeButton.setSize(200, 50);
        resumeButton.setPosition(Gdx.graphics.getWidth() / 2 - resumeButton.getWidth() / 2,
            Gdx.graphics.getHeight() / 2 + 50);
        resumeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });

        TextButton quitButton = new TextButton("Quit", pauseSkin);
        quitButton.setSize(200, 50);
        quitButton.setPosition(Gdx.graphics.getWidth() / 2 - quitButton.getWidth() / 2,
            Gdx.graphics.getHeight() / 2 - 50);
        quitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuScreen(game));
            }
        });

        TextButton saveButton = new TextButton("Save Game", pauseSkin);
        saveButton.setSize(200, 50);
        saveButton.setPosition(
            Gdx.graphics.getWidth() / 2 - saveButton.getWidth() / 2,
            Gdx.graphics.getHeight() / 2 - 150
        );
        saveButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                saveGame();
            }
        });

        pauseStage.addActor(resumeButton);
        pauseStage.addActor(quitButton);
        Gdx.input.setInputProcessor(pauseStage);
    }

    private void hidePauseScreen() {
        pauseStage.clear();
        Gdx.input.setInputProcessor(stage);
    }
    private void createGround() {
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.position.set(0, -0.5f);

        Body groundBody = world.createBody(groundBodyDef);

        PolygonShape groundBox = new PolygonShape();
        groundBox.setAsBox(screenWidth, 20f);

        groundBody.createFixture(groundBox, 0.0f);

        groundBox.dispose();
    }

    @Override
    public void render(float delta) {
        if (isPaused) {
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
            pauseStage.act(delta);
            pauseStage.draw();
            return;
        }

        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        world.step(1 / 60f, 6, 2);

        debugRenderer.render(world, camera.combined);

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (CreateStructure structure : structures) {
            structure.render(shapeRenderer);
        }

        for (Pig pig : pigs) {
            pig.render(shapeRenderer);
        }

        if (allPigsDestroyed()) {
            nextLevelButton.setVisible(true);
        }

        catapult.render();
        shapeRenderer.end();

        stage.act(delta);
        stage.draw();
    }

    private boolean allPigsDestroyed() {
        for (Pig pig : pigs) {
            if (!pig.isDestroyed()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
        pauseStage.getViewport().update(width, height, true);
    }

    @Override
    public void hide() {
        world.dispose();
        debugRenderer.dispose();

        shapeRenderer.dispose();

        if (catapult != null) {
            catapult.dispose();
        }

        if (stage != null) {
            stage.dispose();
        }

        if (skin != null) {
            skin.dispose();
        }

        for (CreateStructure structure : structures) {
            structure.dispose();
        }

        for (Pig pig : pigs) {
            pig.dispose();
        }

        Gdx.input.setInputProcessor(null);
    }
    public List<Pig> getPigsLeft() {
        List<Pig> remainingPigs = new ArrayList<>();
        for (Pig pig : pigs) {
            if (!pig.isDestroyed()) {
                remainingPigs.add(pig);
            }
        }
        return remainingPigs;
    }
    public List<CreateStructure> getStructuresLeft() {
        List<CreateStructure> remainingStructures = new ArrayList<>();
        for (CreateStructure structure : structures) {
            if (!structure.isDestroyed()) {
                remainingStructures.add(structure);
            }
        }
        return remainingStructures;
    }
    @Override
    public void dispose() {
        hide();
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    public void saveGame() {
        List<Integer> remainingCollisionsStructures = new ArrayList<>();
        List<List<Integer>> structureSizes = new ArrayList<>();
        List<Vector2> structurePositions = new ArrayList<>();
        List<Integer> remainingCollisionsPigs = new ArrayList<>();
        List<Float> pigSizes = new ArrayList<>();
        List<Vector2> pigPositions = new ArrayList<>();
        for (CreateStructure structure : structures) {
            if (!structure.isDestroyed()) {
                remainingCollisionsStructures.add(structure.getRemainingCollisions());
                structureSizes.add(structure.getsize());
                structurePositions.add(structure.getPosition());
            }
        }
        for (Pig pig : pigs) {
            if (!pig.isDestroyed()) {
                remainingCollisionsPigs.add(pig.getRemainingCollisions());
                pigSizes.add(pig.getsize());
                pigPositions.add(pig.getPosition());
            }
        }
        GameState gameState = new GameState(1, remainingCollisionsStructures, remainingCollisionsPigs,
            birdsleft, pigSizes, structureSizes,
            structurePositions, pigPositions);
        GameSaver.saveGame(gameState, "game_state.ser");
    }
}
