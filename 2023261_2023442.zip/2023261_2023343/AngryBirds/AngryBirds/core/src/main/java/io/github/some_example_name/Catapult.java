package io.github.some_example_name;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.joints.MouseJoint;
import com.badlogic.gdx.physics.box2d.joints.MouseJointDef;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJoint;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJointDef;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

import java.util.List;

import static com.badlogic.gdx.graphics.Color.*;

public class Catapult extends ApplicationAdapter {
    private World world;
    private OrthographicCamera camera;
    private float baseX, baseY;
    private RevoluteJoint ballJoint;
    private Box2DDebugRenderer debugRenderer;
    private ShapeRenderer shapeRenderer;
    private Vector2 dragStartPosition;
    private Body base, arm, ball, groundBody;
    private MouseJoint mouseJoint;
    private Vector2 mouseWorldPosition;
    private boolean isDragging = false;
    private Texture ballTexture;
    private SpriteBatch spriteBatch;

    private int maxBalls = 3;
    private int ballCount = 0;
    private int ballColorIndex = 0;
    private final Color[] ballColors = {RED, BLUE, GREEN};
    private final float[] ballSizes = {12f, 14f, 16f};
    private final float[] ballSpeeds = {15.0f, 25.0f, 35.0f};
    private Skin skin;
    private Stage stage;
    private long lastBallLaunchTime = 0;
    public void setMaxBirds(int maxBalls) {
        this.maxBalls = maxBalls;
    }
    private List<Pig> enemies;
    private boolean areAllEnemiesDestroyed() {
        for (Pig pig : enemies) {
            if (!pig.isDestroyed()) {
                return false;
            }
        }
        return true;
    }
    private void showLevelFailedDialog() {
        Dialog levelFailedDialog = new Dialog("Level Failed", skin);
        levelFailedDialog.text("You have reached the maximum number of birds without destroying all the pigs.");
        levelFailedDialog.button("OK", true);
        levelFailedDialog.show(stage);
    }

    public Catapult(World world, OrthographicCamera camera, float baseX, float baseY, Skin skin, Stage stage,List<Pig> enemies) {
        this.world = world;
        this.camera = camera;
        this.baseX = baseX;
        this.baseY = baseY;
        this.skin = skin;
        this.stage = stage;
        debugRenderer = new Box2DDebugRenderer();
        shapeRenderer = new ShapeRenderer();
        spriteBatch = new SpriteBatch();
        this.enemies = enemies;
        ballTexture = new Texture(Gdx.files.internal("red.png"));
        createGround();
        createBase(baseX, baseY);
        createArm(baseX, baseY + 1);
        createBall();
    }

    private void createGround() {
        BodyDef groundDef = new BodyDef();
        groundDef.type = BodyDef.BodyType.StaticBody;
        groundDef.position.set(0, 2);

        groundBody = world.createBody(groundDef);
        PolygonShape groundShape = new PolygonShape();
        groundShape.setAsBox(Gdx.graphics.getWidth(), 20f);

        groundBody.createFixture(groundShape, 0);
        groundShape.dispose();
    }

    private void createBase(float x, float y) {
        BodyDef baseDef = new BodyDef();
        baseDef.type = BodyDef.BodyType.StaticBody;
        baseDef.position.set(x, y);

        base = world.createBody(baseDef);

        PolygonShape baseShape = new PolygonShape();
        baseShape.setAsBox(20, 20f);

        base.createFixture(baseShape, 0);
        baseShape.dispose();
    }

    private void createArm(float x, float y) {
        BodyDef armDef = new BodyDef();
        armDef.type = BodyDef.BodyType.DynamicBody;
        armDef.position.set(x, y);

        arm = world.createBody(armDef);

        PolygonShape armShape = new PolygonShape();
        armShape.setAsBox(20, 10f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = armShape;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 0.5f;
        fixtureDef.restitution = 0.3f;

        arm.createFixture(fixtureDef);
        armShape.dispose();

        RevoluteJointDef jointDef = new RevoluteJointDef();
        jointDef.bodyA = base;
        jointDef.bodyB = arm;
        jointDef.localAnchorA.set(0, 0.5f);
        jointDef.localAnchorB.set(-2, 0);
        jointDef.enableLimit = true;
        jointDef.lowerAngle = -0.5f;
        jointDef.upperAngle = 0.5f;

        world.createJoint(jointDef);
    }

    private void createBall() {
        if (ballCount >= maxBalls) {
            System.out.println("Maximum number of birds reached!");
            return;
        }

        BodyDef ballDef = new BodyDef();
        ballDef.type = BodyDef.BodyType.DynamicBody;
        ballDef.position.set(baseX + 3, baseY + 1);

        ball = world.createBody(ballDef);

        float ballRadius = ballSizes[ballCount % ballSizes.length];
        CircleShape ballShape = new CircleShape();
        ballShape.setRadius(ballRadius);

        Color ballColor = ballColors[ballCount % ballColors.length];

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = ballShape;
        fixtureDef.density = 1.0f - (0.2f * ballCount);
        fixtureDef.friction = 0.5f;
        fixtureDef.restitution = 1f + (0.2f * ballCount);

        ball.createFixture(fixtureDef);
        ballShape.dispose();

        ballCount++;

        attachBallToCatapult();

        System.out.println("Bird created and attached! Bird count: " + ballCount);
    }




    private void attachBallToCatapult() {
        if (ball == null || arm == null) return;

        RevoluteJointDef jointDef = new RevoluteJointDef();
        jointDef.bodyA = arm;
        jointDef.bodyB = ball;
        jointDef.localAnchorA.set(2, 0);
        jointDef.localAnchorB.set(0, 0);
        jointDef.enableLimit = false;
        jointDef.collideConnected = false;

        ballJoint = (RevoluteJoint) world.createJoint(jointDef);
    }

    private void releaseBall() {
        if (mouseJoint != null) {
            world.destroyJoint(mouseJoint);
            mouseJoint = null;
        }

        if (ballJoint != null) {
            world.destroyJoint(ballJoint);
            ballJoint = null;
            launchBall();
        }
    }

    private void launchBall() {
        if (ball != null) {
            Vector2 impulse = new Vector2(ballSpeeds[ballColorIndex], ballSpeeds[ballColorIndex]);
            ball.applyLinearImpulse(impulse, ball.getWorldCenter(), true);

            ballColorIndex = (ballColorIndex + 1) % ballColors.length;

            lastBallLaunchTime = System.currentTimeMillis();

            createBall();
        }
    }


    @Override
    public void render() {
        world.step(1 / 60f, 6, 2);

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(Gdx.gl.GL_COLOR_BUFFER_BIT);

        camera.update();

        handleInput();

        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        renderBody(base, Color.BROWN);
        if (ball != null) {
            renderBallWithTexture();
        }
        renderBody(arm, Color.GRAY);

        if (ball != null) {
            renderBody(ball, ballColors[ballColorIndex]);
        }

        shapeRenderer.end();

        debugRenderer.render(world, camera.combined);
        if (ballCount>= maxBalls && !areAllEnemiesDestroyed()) {
            showLevelFailedDialog();
        }
    }
    public int getBirdsLeft() {
        return maxBalls - ballCount;
    }

    private void renderBallWithTexture() {
        if (ball != null) {
            spriteBatch.setProjectionMatrix(camera.combined);
            spriteBatch.begin();

            Vector2 ballPosition = ball.getPosition();

            float ballRadius = ballSizes[ballCount % ballSizes.length];

            float diameter = ballRadius * 2;

            spriteBatch.draw(ballTexture, ballPosition.x - ballRadius, ballPosition.y - ballRadius, diameter, diameter);

            spriteBatch.end();
        }
    }

    private void handleInput() {
        Vector3 mouseWorldPos3D = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
        camera.unproject(mouseWorldPos3D);
        mouseWorldPosition = new Vector2(mouseWorldPos3D.x, mouseWorldPos3D.y);

        if (Gdx.input.isTouched()) {
            if (!isDragging) {
                createMouseJoint();
                dragStartPosition = new Vector2(mouseWorldPosition);
                isDragging = true;
            }
            if (mouseJoint != null) {
                mouseJoint.setTarget(mouseWorldPosition);
            }
        } else {
            if (isDragging && mouseJoint != null) {
                releaseBallWithTrajectory();
            }
            isDragging = false;
        }
    }

    private void releaseBallWithTrajectory() {
        if (mouseJoint != null) {
            world.destroyJoint(mouseJoint);
            mouseJoint = null;
        }

        if (ballJoint != null) {
            world.destroyJoint(ballJoint);
            ballJoint = null;

            if (ball != null) {
                Vector2 releaseVelocity = mouseWorldPosition.sub(dragStartPosition).scl(5f);
                ball.setLinearVelocity(releaseVelocity);

                System.out.println("Bird released with velocity: " + releaseVelocity);
            }

            createBall();
        }
    }


    private void createMouseJoint() {
        if (mouseJoint == null && ball != null) {
            MouseJointDef mouseJointDef = new MouseJointDef();
            mouseJointDef.bodyA = groundBody;
            mouseJointDef.bodyB = ball;
            mouseJointDef.target.set(mouseWorldPosition);
            mouseJointDef.maxForce = 1000.0f * ball.getMass();

            mouseJoint = (MouseJoint) world.createJoint(mouseJointDef);
        }
    }

    private void renderBody(Body body, Color color) {
        shapeRenderer.setColor(color);
        if (body.getFixtureList().get(0).getShape() instanceof CircleShape) {
            CircleShape shape = (CircleShape) body.getFixtureList().get(0).getShape();
            shapeRenderer.circle(body.getPosition().x, body.getPosition().y, shape.getRadius(), 30);
        }
    }

    @Override
    public void dispose() {
        world.dispose();
        debugRenderer.dispose();
        shapeRenderer.dispose();
    }
}
